## [WIP] Note that this Avatar isnt fully complete, and is still in the development process 🗿
# RC Car Reborn! 🏎️ 
###  The return of the prewrite RC Car
## 🏎️ How to Use 🏁 
* Upon equipping the avatar, the RC Car itself would spawn where you stand.
* Pressing `Backtick` will toggle between being able to control the car or not, also called **Control mode**


## 🏎️ Keybinds 🏁 
| Keybind  | Special    | Action                       | Control Mode only |
| -------- | ---------- | ---------------------------- | ----------------- |
| `        |            | Toggles between Control mode |                  |
| W / S    |            | Throttles the RC             | ✔                 |
| W & S    |            | Tire Burning                 | ✔                 |
| A / D    |            | Steers the RC                | ✔                 |
| F        |            | Honk                         | ✔                 |
| Spacebar |            | Jump                         | ✔                 |
| `        | Double tap | Respawn Car                  |                   |

## 🏎️ New since Prewrite🏁 
* Suspension
* Generally more Optimized code
* More Updates SOON!