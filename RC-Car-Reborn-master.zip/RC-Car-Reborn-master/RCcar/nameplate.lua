nameplate.ALL:setText(":racecar:${name}${badges}")
nameplate.ENTITY:setBackgroundColor(0,0,0,0)
nameplate.ENTITY:setOutline(true)